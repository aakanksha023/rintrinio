#### Team Andrey Markov

##### Contributors:

- Chahma, Sirine
- Dimri, Aakanksha
- Solomon, Samantha 
- Zhang, Roc 


