library(testthat)
library(rintrinio)

test_check("rintrinio")
